<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Home Page</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body style="background-color:#fdcb6e"> 

<div id="main-wrapper" >
<center><h2>Home Page</h2>
<h2>Welcome brother
</h2>

<img src="imgs/man2.jpg" class="ram"/>
</center>
<p>
<h2> Qustion</h2>
What is GST?<br>
<h2> Answer</h2>
GST (goods and service tax) has been treated as one of the major tax reforms of all time. It will now be known as the one and only tax customers need to pay as a replacement of VAT, service tax, excise duty, luxury tax, etc and It combines indirect tax for the whole country and make this country a single market where everyone is bound to get a GST registration Online.
</p>
<p>
<h2> Qustion</h2>
What is GST Registration?<>
<h2> Answer</h2>
GST is a kind of registration where people need to submit their legal documents and get a unique GST number online which will represent them uniquely in the market.
</p>
<p>
<h2> Qustion</h2>
How to get certificate of GST registration?<br>
<h2> Answer</h2>
When the annual turnover starts exceeding Rs 20 lakh or exchange of goods and services are upgraded to interstate then you have to do a GST Online Registration and it is better to get your new GST Registration certificate online since it is easy and quick with the help of certain professionals.
</p>
<form class="myform" action="HomePage.php" method="POST">

<a href="Login.php"><input name="Long" type="button" id="longout_btn" value="Logout"/><br></a>
</form>

</div>
</body>
</html>